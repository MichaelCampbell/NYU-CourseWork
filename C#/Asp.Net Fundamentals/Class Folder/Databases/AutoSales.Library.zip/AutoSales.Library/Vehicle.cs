﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoSales.Library
{
    public class Vehicle
    {
        public int Id { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public VehicleColor Color { get; set; }
        public int Year { get; set; }
        public int Price { get; set; }
    }

    public enum VehicleColor
    {
        Other,
        Red,
        Blue,
        Black,
        Silver,
        Green
    }
}
