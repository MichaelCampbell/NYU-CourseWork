﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlServerCe;

namespace AutoSales.Library
{
    public static class VehicleHelper
    {
        static Vehicle ConvertToVehicle(IDataReader dr)
        {
            return new Vehicle
            {
                Id = dr.GetInt32(dr.GetOrdinal("Id")),
                Make = dr.GetString(dr.GetOrdinal("Make")),
                Model = dr.GetString(dr.GetOrdinal("Model")),
                Color = (VehicleColor)dr.GetInt32(dr.GetOrdinal("Color")),
                Year = dr.GetInt32(dr.GetOrdinal("Year")),
                Price = dr.GetInt32(dr.GetOrdinal("Price"))
            };
        }

        public static class SQLOLEDB
        {
            public static List<Vehicle> GetInventory()
            {
                List<Vehicle> list = new List<Vehicle>();

                string cstr = ConfigurationManager.ConnectionStrings["AutoSales_MDB"].ConnectionString;
                using (OleDbConnection conn = new OleDbConnection(cstr))
                {
                    using (OleDbCommand cmd = new OleDbCommand("SELECT * FROM Vehicle", conn))
                    {
                        conn.Open();

                        IDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                        while (rdr.Read())
                            list.Add(ConvertToVehicle(rdr));

                        rdr.Close();
                    }

                }
                return list;
            }

            public static void Save(Vehicle v)
            {
                bool isNew = v.Id == 0;
                string cstr = ConfigurationManager.ConnectionStrings["AutoSales_MDB"].ConnectionString;

                using (OleDbConnection conn = new OleDbConnection(cstr))
                {
                    string sql = "";
                    if (isNew)
                        sql = "INSERT INTO `Vehicle` (`Make`, `Model`, `Year`, `Price`, `Color`) VALUES (?,?,?,?,?);";
                    else
                        sql = string.Format("UPDATE `Vehicle` SET`Make`=?, `Model`=?, `Year`=?, `Price`=?, `Color`=? WHERE VehicleKey=? ;",
                                                 v.Make, v.Model, v.Color, v.Year, v.Price, v.Id);

                    using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("Make", v.Make);
                        cmd.Parameters.AddWithValue("Model", v.Model);
                        cmd.Parameters.AddWithValue("Year", v.Year);
                        cmd.Parameters.AddWithValue("Price", v.Price);
                        cmd.Parameters.AddWithValue("Color", v.Color);

                        if (!isNew)
                        {
                            cmd.Parameters.AddWithValue("VehicleKey", v.Id);
                        }
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
            }
        }

        public static class SQLCE
        {
            public static List<Vehicle> GetInventory()
            {
                List<Vehicle> list = new List<Vehicle>();

                string cstr = ConfigurationManager.ConnectionStrings["AutoSales_CE"].ConnectionString;
                using (SqlCeConnection conn = new SqlCeConnection(cstr))
                {
                    using (SqlCeCommand cmd = new SqlCeCommand("SELECT * FROM Vehicle", conn))
                    {
                        conn.Open();

                        IDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                        while (rdr.Read())
                            list.Add(ConvertToVehicle(rdr));

                        rdr.Close();
                    }

                }
                return list;
            }

            public static void Save(Vehicle v)
            {
                bool isNew = v.Id == 0;
                string cstr = ConfigurationManager.ConnectionStrings["AutoSales_CE"].ConnectionString;

                using (SqlCeConnection conn = new SqlCeConnection(cstr))
                {
                    string sql = "";
                    if (isNew)
                        sql = "INSERT INTO Vehicle (Make, Model, Year, Price, Color) VALUES (?,?,?,?,?);";
                    else
                        sql = string.Format("UPDATE Vehicle SETMake=?, Model=?, Year=?, Price=?, Color=? WHERE Id=? ;",
                                                 v.Make, v.Model, v.Color, v.Year, v.Price, v.Id);

                    using (SqlCeCommand cmd = new SqlCeCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("Make", v.Make);
                        cmd.Parameters.AddWithValue("Model", v.Model);
                        cmd.Parameters.AddWithValue("Year", v.Year);
                        cmd.Parameters.AddWithValue("Price", v.Price);
                        cmd.Parameters.AddWithValue("Color", v.Color);

                        if (!isNew)
                        {
                            cmd.Parameters.AddWithValue("Id", v.Id);
                        }
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
            }
        }
    }
}
