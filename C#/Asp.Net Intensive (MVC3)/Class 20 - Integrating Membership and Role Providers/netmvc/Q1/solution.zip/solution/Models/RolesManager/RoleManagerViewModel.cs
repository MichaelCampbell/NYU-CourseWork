﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MembershipApp.Models.RolesManager
{
    public class RoleManagerViewModel
    {
        public List<string> Roles { get; set; }

        public int Index { get; set; }

    }
}