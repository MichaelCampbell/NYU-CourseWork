﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BUS
{
    public class Friend
    {
        public int ContactId1 { get; set; }
        public int ContactId2 { get; set; }
    }
}
