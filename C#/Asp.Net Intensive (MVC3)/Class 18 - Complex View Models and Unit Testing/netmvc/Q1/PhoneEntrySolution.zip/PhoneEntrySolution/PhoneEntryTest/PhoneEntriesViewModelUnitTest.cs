﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PhoneEntryTest
{
    [TestClass]
    public class PhoneEntriesViewModelUnitTest
    {
        [TestMethod]
        public void TestMethod2()
        {

        }

        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
