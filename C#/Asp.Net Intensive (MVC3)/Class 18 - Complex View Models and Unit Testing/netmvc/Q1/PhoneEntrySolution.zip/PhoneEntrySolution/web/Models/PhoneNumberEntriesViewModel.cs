﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace web.Models
{
    public class PhoneNumberEntriesViewModel
    {
        private List<PhoneNumberEntry> _entries;

        public List<PhoneNumberEntry> Entries 
        {
            set { _entries = value; }
            get
            {
                if (_entries == null)
                    Entries = new List<PhoneNumberEntry>();
                return _entries;
            }
        }


        public List<PhoneNumberTypes> AllTypes()
        {
            return null;
        }

        public List<PhoneNumberTypes> UsedTypes()
        {
            return null;
        }

        public List<PhoneNumberTypes> AvailableTypes()
        {
            return null;
        }

        public List<PhoneNumberTypes> AvailableTypes(PhoneNumberEntry entry)
        {
            return null;
        }

        public List<SelectListItem> SelectListItems(PhoneNumberEntry entry)
        {
            return null;
        }
    }
}