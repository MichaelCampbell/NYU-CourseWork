﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using web.Models.Admin;

namespace web.Controllers
{
    [Authorize(Roles="Admin")]
    public class AdminController : Controller
    {

        public ActionResult Users(string role = "All")
        {
            var roles = Roles.GetAllRoles().ToList();
            roles.Insert(0, "All");
            var model = new UsersViewModel { };
            model.Roles = roles.Select(
                r => new SelectListItem { Text = r, Selected = r == role}
                ).ToList();

            model.Users = Membership.GetAllUsers().OfType<MembershipUser>().Where(u => role == "All" || Roles.IsUserInRole(u.UserName, role)).ToList();

            return View(model);
        }

    }
}
