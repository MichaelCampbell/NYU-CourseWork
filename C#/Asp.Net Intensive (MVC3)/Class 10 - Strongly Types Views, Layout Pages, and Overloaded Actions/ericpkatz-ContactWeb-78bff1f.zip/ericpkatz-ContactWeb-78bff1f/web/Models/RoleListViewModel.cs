﻿using System.Collections.Generic;


namespace ContactWeb.Models
{
    public class RoleListViewModel
    {
        public List<string> Roles { get; set; }
    }
}