﻿(function() {
  alert("x");
}).call(this);
