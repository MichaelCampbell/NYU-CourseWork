﻿namespace ContactWebLibrary
{
    public enum ContactFriendsStatus
    {
        NoFriends,
        HasFriends
    }
}
