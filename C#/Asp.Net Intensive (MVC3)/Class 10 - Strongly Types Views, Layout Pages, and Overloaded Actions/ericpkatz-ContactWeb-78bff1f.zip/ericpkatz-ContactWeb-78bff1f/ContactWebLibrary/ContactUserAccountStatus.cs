﻿namespace ContactWebLibrary
{
    public enum ContactUserAccountStatus
    {
        UserAccount,
        NoUserAccount
    }
}
