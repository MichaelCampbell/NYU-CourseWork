/*This program is intended to convert Celsius to Fahrenheit*/

#include<stdio.h>

int main (void)
{
	float c;
	float f = 27.0;

	c = (f - 32) / 1.8;
	printf("%f degrees Fahrenheit is equivalent to %f degrees Celcius\n", f, c);
	
	return 0;

}