/*
  Program: Hello.c
  Author: Michael Campbell
  Date: 5/25/10
  synopsis: to say hello

*/

#include <stdio.h>

int main(void)
{

	int x = 10;
	int y = 20;
	float z;

	z = x * y;

	printf("Hello World: X = %d\t y = %d\t z = %5.2f\n", x, y, z);

	return 0;
}